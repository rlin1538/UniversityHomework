package nuaa.softrely.tomax.homework;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * @Author: ToMax
 * @Description:
 * @Date: Created in 2018/11/19 22:46
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({TestGoelOkumotoModel.class, TestJelinskiMorandaModel.class})
public class TestAll {

}
