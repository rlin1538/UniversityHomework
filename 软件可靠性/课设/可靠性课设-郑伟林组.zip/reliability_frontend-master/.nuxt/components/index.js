export { default as DataSource } from '../..\\components\\DataSource.vue'
export { default as ModelList } from '../..\\components\\ModelList.vue'
export { default as Params } from '../..\\components\\Params.vue'
export { default as Result } from '../..\\components\\Result.vue'

export const LazyDataSource = import('../..\\components\\DataSource.vue' /* webpackChunkName: "components_DataSource" */).then(c => c.default || c)
export const LazyModelList = import('../..\\components\\ModelList.vue' /* webpackChunkName: "components_ModelList" */).then(c => c.default || c)
export const LazyParams = import('../..\\components\\Params.vue' /* webpackChunkName: "components_Params" */).then(c => c.default || c)
export const LazyResult = import('../..\\components\\Result.vue' /* webpackChunkName: "components_Result" */).then(c => c.default || c)
