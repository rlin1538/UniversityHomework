package com.reliability.dto;

import lombok.Data;

@Data
public class PageDTO {
    private int page;
    private int size;
}
