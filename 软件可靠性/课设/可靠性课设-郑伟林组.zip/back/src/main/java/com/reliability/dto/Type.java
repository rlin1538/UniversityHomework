package com.reliability.dto;

public enum Type {
    MYSQL,
    POSTGRES
}
