# reliability

NUAA 软件可靠性课程设计后端部分，采用 springboot 编写

# 前端
[frontend](https://github.com/Creedowl/reliability_frontend)
