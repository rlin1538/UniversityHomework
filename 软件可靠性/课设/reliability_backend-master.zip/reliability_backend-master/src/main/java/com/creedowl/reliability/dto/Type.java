package com.creedowl.reliability.dto;

public enum Type {
    MYSQL,
    POSTGRES
}
