package com.creedowl.reliability.dto;

import lombok.Data;

@Data
public class PageDTO {
    private int page;
    private int size;
}
