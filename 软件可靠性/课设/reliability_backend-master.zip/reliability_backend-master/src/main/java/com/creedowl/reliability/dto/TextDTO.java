package com.creedowl.reliability.dto;

import lombok.Data;

@Data
public class TextDTO {
    private String text;
}
