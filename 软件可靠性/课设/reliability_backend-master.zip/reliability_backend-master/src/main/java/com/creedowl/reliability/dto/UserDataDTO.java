package com.creedowl.reliability.dto;

import lombok.Data;

@Data
public class UserDataDTO {
    private String username;
    private String password;
}
