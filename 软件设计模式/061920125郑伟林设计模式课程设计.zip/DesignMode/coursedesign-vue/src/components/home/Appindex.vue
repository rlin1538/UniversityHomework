<template>
  <div>
  </div>
</template>

<script>
export default {
  name: 'AppIndex'
}
</script>

<style scoped>

</style>
