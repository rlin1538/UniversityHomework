package com.example.testend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestEndApplicationTests {

    @Test
    void contextLoads() {
    }

}
