from selenium import webdriver
import time

brower = webdriver.Firefox()
brower.get("http://dounine.live")
username_input = brower.find_element_by_xpath("/html/body/div/div/div[1]/form/div[1]/div/div/input")
username_input.send_keys("dounine")
passwd_input = brower.find_element_by_xpath("/html/body/div/div/div[1]/form/div[2]/div/div/input")
passwd_input.send_keys("19991006")
login_btn = brower.find_element_by_class_name("login-button")
login_btn.click()

time.sleep(2)

article = brower.find_element_by_xpath("/html/body/div/section/main/ul/li[5]/div[3]/div[2]/div/div/div[1]/div/a")
article.click()