# coding = utf-8
from selenium import webdriver
import time

browser = webdriver.Firefox()
time.sleep(1)
browser.get("http://www.baidu.com")
time.sleep(1)
browser.find_element_by_id("kw").send_keys("南京航空航天大学")
time.sleep(1)
browser.find_element_by_id("su").click()
time.sleep(1)
browser.find_element_by_xpath("/html/body/div[1]/div[5]/div[1]/div[3]/div[1]/h3/a[1]").click()
time.sleep(1)
print(browser.current_url)
browser.switch_to.window(browser.window_handles[1])
time.sleep(1)
print(browser.current_url)
# browser.quit()