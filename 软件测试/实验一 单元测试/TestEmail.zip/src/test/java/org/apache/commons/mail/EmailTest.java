package org.apache.commons.mail;

import static org.junit.Assert.*;

public class EmailTest {
    private Email email;

    @org.junit.Before
    public void setUp() throws Exception {
        email = new SimpleEmail();
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    @org.junit.Test
    public void setFrom() {
    }

    @org.junit.Test
    public void addTo() {
    }

    @org.junit.Test
    public void setSubject() {
    }
}
