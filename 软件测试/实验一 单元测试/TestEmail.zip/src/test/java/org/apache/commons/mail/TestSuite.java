package org.apache.commons.mail;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        SimpleEmailTest.class,
        EmailTest.class
})
public class TestSuite {
}
