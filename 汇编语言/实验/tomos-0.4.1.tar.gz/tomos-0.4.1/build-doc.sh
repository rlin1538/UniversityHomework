#!/bin/bash

cd source
../tools/docgen
