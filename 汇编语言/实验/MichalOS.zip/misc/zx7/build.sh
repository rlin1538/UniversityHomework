#!/bin/bash

cc zx7.c optimize.c compress.c -o /usr/bin/zx7
