tfunction.clear;
	getfunction();
	for (int i = 0; i < tfunction.size(); i++) {
		cout << tfunction[i] << endl;
		out << tfunction[i] << endl;
	}