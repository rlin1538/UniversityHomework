# Typing Game

最简单的打字小游戏。
这是[NJU 2013 oslab0的演示游戏](https://github.com/NJU-ProjectN/os-lab0)的AM移植版本。
需要正确的IOE (计时、绘图、键盘)。

