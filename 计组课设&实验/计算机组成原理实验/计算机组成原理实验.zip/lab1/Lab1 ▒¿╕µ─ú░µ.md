# Lab1 报告模版

* 姓名：张三
* 班级：1619205
* 学号：161920501
* 报告阶段：lab1
* 完成日期：2021.4.1
* 本次实验，我完成了所有内容。

## 目录

[TOC]

## 1. Nuaa_question1

* 思路
* 代码
* 测试截图（dlc btest）

## 2. Nuaa_question2

* 思路
* 代码
* 测试截图（dlc btest）

## 3. Nuaa_question3

* 思路
* 代码
* 测试截图（dlc btest）

## 4. Nuaa_question4

* 思路
* 代码
* 测试截图（dlc btest）

## 5. Nuaa_question5

* 思路
* 代码
* 测试截图（dlc btest）

## 6. Nuaa_question6

* 思路
* 代码
* 测试截图（dlc btest）

## 7. 最终结果

* ./driver.pl 截图
* 挑战教授截图（必须是你的学号）

## 8. 备注

助教真帅

